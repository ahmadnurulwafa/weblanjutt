<!-- Begin Page Content -->
<div class="container col-8">
    <!-- Page Heading -->
    <div class="card">
    <div class="text-center mt-4">
            <h3>Masukkan Data</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="container-fluid">
                    <?= validation_errors() ?>
                    <form action="<?= base_url('admin/proses_update_vaksin/' . $data->id_vaksin)  ?>" method="POST" enctype="multipart/form-data">
                        <table class="table">
                            <tr>
                                <td width=20%>Nama Vaksin</td>
                                <td><input type="text" name="nama_vaksin" class="form-control" required placeholder="Nama Vaksin" value="<?= $data->nama_vaksin ?>"></td>
                            </tr>
                            <tr>
                                <td width=20%>Jumlah Vaksin</td>
                                <td><input type="number" name="jumlah" value="<?= $data->jumlah ?>" class="form-control" required placeholder="Jumlah Vaksin"></td>
                            </tr>
                            <tr>
                                <td>
                                    <button class="btn btn-success">Simpan</button>
                                </td>
                                <td></td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>