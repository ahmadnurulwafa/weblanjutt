<!-- Begin Page Content -->
<div class="container col-8">
    <!-- Page Heading -->
    <div class="card">
    <div class="text-center mt-4">
            <h3>Masukkan Data</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="container-fluid">
                    <?= validation_errors() ?>
                    <form action="<?= base_url('admin/proses_update_dokter/' . $data->id_dokter)  ?>" method="POST" enctype="multipart/form-data">
                        <table class="table">
                            <tr>
                                <td width=20%>Nama Vaksin</td>
                                <td><input type="text" name="nama_dokter" class="form-control" required placeholder="Nama Dokter" value="<?= $data->nama_dokter ?>"></td>
                            </tr>

                            <tr>
                                <td>Jenis Kelamin</td>
                                <td><select class="form-control" name="jk">
                                        <option value="Laki-Laki">Laki-Laki</option>
                                        <option value="Perempuan">Perempuan</option>
                                    </select></td>
                            </tr>
                            <tr>
                                <td>Tanggal Lahir</td>
                                <td><input type="date" name="ttl" value="<?= $data->ttl ?>" class="form-control">
                                </td>
                            </tr>
                            <tr>
                                <td>Alamat Saat Ini</td>
                                <td><textarea name="alamat" class="form-control"><?= $data->alamat ?></textarea></td>
                            </tr>

                            <tr>
                                <td>Telpon</td>
                                <td><input type="text" name="telpon" class="form-control" value="<?= $data->telpon ?>" required placeholder="Telpon"></td>
                            </tr>
                            <tr>
                                <td>
                                    <button class="btn btn-success">Simpan</button>
                                </td>
                                <td></td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>